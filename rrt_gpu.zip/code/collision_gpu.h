//
// Created by paras on 13/04/21.
//

#ifndef ASSIGNMENT01_COLLISION_GPU_H
#define ASSIGNMENT01_COLLISION_GPU_H

void is_colliding_gpu(Node node, Node* obstacles, bool* col, int obs_size);

#endif //ASSIGNMENT01_COLLISION_GPU_H
