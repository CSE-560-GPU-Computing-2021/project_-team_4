# 1 "/home/paras/Downloads/GPU/Assignment1/code/main.cu"
extern struct __C8 *__curr_eh_stack_entry;
extern unsigned short __eh_curr_region;
extern int __catch_clause_number;
# 61 "/usr/include/c++/7/iostream" 3
extern _ZSt7ostream _ZSt4cout __attribute__((visibility("default")));
# 74 "/usr/include/c++/7/iostream" 3
static struct _ZNSt8ios_base4InitE _ZN34_INTERNAL_12_main_cpp1_ii_b0423336St8__ioinitE __attribute__((visibility("default"))) = {};
extern void *__dso_handle __attribute__((visibility("hidden")));
