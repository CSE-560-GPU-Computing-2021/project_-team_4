# 1 "/home/paras/Downloads/GPU/Assignment1/code/collision_gpu.cu"
# 137 "/usr/include/stdio.h" 3
extern struct _IO_FILE *stderr;
# 74 "/usr/include/c++/7/iostream" 3
static struct _ZNSt8ios_base4InitE _ZN43_INTERNAL_21_collision_gpu_cpp1_ii_67ba57a3St8__ioinitE __attribute__((visibility("default"))) = {};
extern void *__dso_handle __attribute__((visibility("hidden")));
