#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-function"
#pragma GCC diagnostic ignored "-Wcast-qual"
#define __NV_CUBIN_HANDLE_STORAGE__ static
#if !defined(__CUDA_INCLUDE_COMPILER_INTERNAL_HEADERS__)
#define __CUDA_INCLUDE_COMPILER_INTERNAL_HEADERS__
#endif
#include "crt/host_runtime.h"
#include "collision_gpu.fatbin.c"
typedef std::pair<float, float>  _ZSt4pairIffE;
extern void __device_stub__Z9collisionSt4pairIffEPS0_Pbi( _ZSt4pairIffE&,  _ZSt4pairIffE *, bool *, int);
static void __nv_cudaEntityRegisterCallback(void **);
static void __sti____cudaRegisterAll(void) __attribute__((__constructor__));
void __device_stub__Z9collisionSt4pairIffEPS0_Pbi( _ZSt4pairIffE&__par0,  _ZSt4pairIffE *__par1, bool *__par2, int __par3){__cudaLaunchPrologue(4);__cudaSetupArg(__par0, 0UL);__cudaSetupArgSimple(__par1, 8UL);__cudaSetupArgSimple(__par2, 16UL);__cudaSetupArgSimple(__par3, 24UL);__cudaLaunch(((char *)((void ( *)( _ZSt4pairIffE,  _ZSt4pairIffE *, bool *, int))collision)));}
# 18 "/home/paras/Downloads/GPU/Assignment1/code/collision_gpu.cu"
void collision(  _ZSt4pairIffE __cuda_0, _ZSt4pairIffE *__cuda_1,bool *__cuda_2,int __cuda_3)
# 18 "/home/paras/Downloads/GPU/Assignment1/code/collision_gpu.cu"
{__device_stub__Z9collisionSt4pairIffEPS0_Pbi( __cuda_0,__cuda_1,__cuda_2,__cuda_3);
# 26 "/home/paras/Downloads/GPU/Assignment1/code/collision_gpu.cu"
}
# 1 "collision_gpu.cudafe1.stub.c"
static void __nv_cudaEntityRegisterCallback( void **__T3) {  __nv_dummy_param_ref(__T3); __nv_save_fatbinhandle_for_managed_rt(__T3); __cudaRegisterEntry(__T3, ((void ( *)( _ZSt4pairIffE,  _ZSt4pairIffE *, bool *, int))collision), _Z9collisionSt4pairIffEPS0_Pbi, (-1)); }
static void __sti____cudaRegisterAll(void) {  __cudaRegisterBinary(__nv_cudaEntityRegisterCallback);  }

#pragma GCC diagnostic pop
